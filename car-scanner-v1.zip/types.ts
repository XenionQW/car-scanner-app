export interface CarAnalysis {
  make: string;
  model: string;
  color: string;
  year: string;
}